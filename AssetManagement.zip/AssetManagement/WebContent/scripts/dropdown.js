var Categorie={

	C:["RAM","MotherBorad","DiskDrive"],

	N:["Routers","Data Cards","LAN Cable","HDMI Cable","Network Cards"],

	S:["Pendrive","Hard Disks","Solid State Drives","CD's","DVD's"],

	O:["Data Cards","Sim Cards"]

}

	function changeCategory(value)

	{

		if(value.length==0)

		{

			document.getElementById("Categorie").innerHTML="<option></option>";

		}

		else

		{

			var categoryOptions="";

		for(categories in Categorie[value])

		{

			categoryOptions+="<option>"+Categorie[value][categories]+"</option>";

		}

		document.getElementById("Categorie").innerHTML=categoryOptions;

	}

}