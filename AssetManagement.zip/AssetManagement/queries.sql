select * from tab; 

select * from admin_master;

create table admin_master (username varchar2(10),password varchar(20));

insert into admin_master values ('rohit','rohit@123');