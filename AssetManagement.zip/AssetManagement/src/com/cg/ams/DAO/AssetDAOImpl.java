package com.cg.ams.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;

import com.cg.ams.DBUtil.DBUtil;
import com.cg.ams.bean.User;

public class AssetDAOImpl implements IAssetDAO 
{
	Connection con;
	@Override
	public User getAdminDetails(String unm)
	
	{
	
		try 
		{
			
			con = DBUtil.getConnection();
			String sql = "Select * from admin_master";
			
			PreparedStatement pst = con.prepareStatement(sql);
			
			
		} 
		catch (SQLException e)
		{
			
			e.printStackTrace();
		}
		return null;
	}

}
