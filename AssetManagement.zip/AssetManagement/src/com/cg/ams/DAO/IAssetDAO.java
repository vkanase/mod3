package com.cg.ams.DAO;

import com.cg.ams.bean.User;


public interface IAssetDAO 
{
	public User getAdminDetails(String unm);
}
