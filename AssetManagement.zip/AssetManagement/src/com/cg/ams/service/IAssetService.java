package com.cg.ams.service;

import com.cg.ams.bean.User;

public interface IAssetService 
{
	public User getAdminDetails(String unm);
}
